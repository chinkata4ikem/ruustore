<?php 

$koneksi = mysqli_connect("sql202.epizy.com","epiz_32860186","eAycDOnm2f67Vi","epiz_32860186_priiz");

