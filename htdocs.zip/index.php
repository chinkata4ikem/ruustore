<?php 
include "koneksi.php";

$sql = mysqli_query($koneksi, "SELECT * FROM tb_admin WHERE id = '2'");
$data = mysqli_fetch_object($sql);
 ?>

<!DOCTYPE html>
<html>
    <head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="Content-Security-Policy" content="upgrade-insecure-requests">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
<meta name="theme-color" content="#2d3238">
<meta name="title" content="RuuStore - Top Up Termurah Instant Buka 24 Jam">
<meta name="description" content="RuuStore - Supplier Top Up Instant Game &amp; Voucher termurah, terpercaya, dan aman legal 100% open 24 Jam dengan payment terlengkap Indonesia">

<meta property="og:type" content="website">
<meta property="og:url" content="index.php">
<meta property="og:title" content="BANGJEFF - Top Up Termurah Instant Buka 24 Jam">
<meta property="og:description" content="RuuStore - Supplier Top Up Instant Game &amp; Voucher termurah, terpercaya, dan aman legal 100% open 24 Jam dengan payment terlengkap Indonesia">
<meta property="og:image" content="ruustore.png">
<meta name="robots" content="index, follow">
<meta content="desktop" name="device">
<meta name="author" content="RuuStore">
<meta name="coverage" content="Worldwide">
<meta name="apple-mobile-web-app-title" content="RuuStore - Top Up Termurah Instant Buka 24 Jam">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-touch-fullscreen" content="yes">
<meta name="csrf-token" content="968Yg5tj3noBC2frQBbczPjYS5nkhIagkcRzSQiJ">
<link rel="icon" href="ruustore.png">
<title>RuuStore.id - Top Up Termurah Cepat Buka 24 Jam</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="assets/scss/app.css">
<link rel="stylesheet" href="assets/css/app.css">
<link rel="stylesheet" href="assets/scss/chatbox.css">
    <link rel="stylesheet" href="dist/css/bootstrap.min.css">
    <script src="dist/css/sweetalert2.all.min.js"></script>
<script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script>



<link rel="stylesheet" href="assets/scss/app.css">

<link rel="stylesheet" href="assets/css/app.css">
<link rel="stylesheet" href="assets/scss/chatbox.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<script type="25d7f2a453c98fc378ed16ea-text/javascript">(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
            new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
            j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
            '../www.googletagmanager.com/gtm5445.html'+i+dl;f.parentNode.insertBefore(j,f);
            })(window,document,'script','dataLayer','GTM-KX5ZSG5');</script>

<script src="assets/js/app.js" type="25d7f2a453c98fc378ed16ea-text/javascript"></script>
<style>
            .form-check-input:focus {
                border-color: #fe6c17;
                box-shadow: 0 0 0 0.25rem rgb(13 110 253 / 25%);
                outline: 0;
            }
            .form-check-input:checked {
                background-color: #fe6c17;
                border-color: #fe6c17;
            }
            .btn-primary {
            background-color: #fe6c17;
            border-color: #fe6c17;
            cursor: pointer;
            color: #fff;}

            .btn-primary:hover {
            color: #fff;
            background-color: #c44d09;
            border-color: #c44d09;
            }
            .btn-primary:focus, .btn-primary.focus {
            color: #fff;
            background-color: #c44d09;
            border-color: #c44d09;
            box-shadow: 0 0 0 0.2rem rgba(255, 168, 38, 0.5);
            }
            #searchProds {
                width: 60px;
                transition: width .5s ease
            }

            #searchProds:focus {
                width: 240px
            }

        </style>
<script src="assets/js/jquery.cookie.min.js" integrity="sha512-3j3VU6WC5rPQB4Ld1jnLV7Kd5xr+cq9avvhwqzbH/taCRNURoeEpoPBK9pDyeukwSxwRPJ8fDgvYXd6SkaZ2TA==" crossorigin="anonymous" referrerpolicy="no-referrer" type="25d7f2a453c98fc378ed16ea-text/javascript"></script>
<link rel="stylesheet" href="assets/css/swiper-bundle.min.css" />
<script src="assets/js/swiper-bundle.min.js" type="25d7f2a453c98fc378ed16ea-text/javascript"></script>
<style>
<link rel="stylesheet" href="path/to/font-awesome/css/font-awesome.min.css">
        .img-scale:hover {
            transform: scale(1.1);
            transition: .5s ease;
        }
        .swiper {
          width: 100%;
          /* padding-top: 50px;
          padding-bottom: 50px; */
        }

        .swiper-slide {
          background-position: center;
          background-size: cover;
          width: 80%;
        }

        .swiper-slide img {
          display: block;
          width: 100%;
        }
        .swiper-button-next,
          .swiper-button-prev{
              /* background-color: #fe6c1783; */
              background-color: #fe6c17;
              right:10px;
              padding: 30px;
              color: rgb(255, 255, 255) !important;
              fill: black !important;
              stroke: black !important;
              border-radius: 100px
          }

        .carousel-control-prev-icon,
        .carousel-control-next-icon {
            /* background-color: #fe6c1783; */
            background-color: #fe6c17 !important;
            right:10px;
            padding: 13px;
            color: rgb(255, 255, 255) !important;
            fill: black !important;
            stroke: black !important;
            border-radius: 100px
        }
        .swiper-button-next:after,
        .swiper-button-prev:after{
          font-size:20px !important;
        }
        .swiper-button-next:hover,
        .swiper-button-prev:hover{
          background-color: #fe6c17;
        }
        .swiper-pagination-bullet-active{
          background-color:#fe6c17;
        }
        .nav-tab{
            background-color: #a44006;
            border-radius: 0.25rem;
            color: white !important;
        }
        .nav-tab .nav-link{
            color: white !important;
        }
        .nav-tab:hover{
            background-color: #ae480d;
            border-radius: 0.25rem;
        }
        .horitab-scroll{
            display: flex;
            flex-wrap: nowrap;
            padding-bottom: 1.5rem;
            padding-left: 0;
            margin-block: 0;
            /* overflow-x: auto; */
            list-style: none;
            text-align: center;
            white-space: nowrap;
            overflow: auto;
        }
      </style>
    </head>
    <style>
    .bangjeff-pgimg {
        background-color: white;
        border-radius: 3px;
        border: 1px solid white;
        height: 15px;
    }
    .bjlink {
        text-decoration: none;
    }
    .ratakirikanan {
        text-align: justify;
    }
    .bg-light {
      --bs-bg-opacity: 1;
    }
    .grecaptcha-badge {
        visibility: hidden;
    }

    .logo-atas {
        height: 30px;
    }
    .logo-order {
        width: 100%;
        float: left;
        /* margin-right: 8px;
        margin-bottom: auto; */
    }
    .logo-order2 {
        width: 100%;
        float: left;
        /* margin-right: 8px;
        margin-bottom: auto; */
    }
    .logo-order3 {
        width: 100%;
        float: left;
        /* margin-right: 8px;
        margin-bottom: auto; */
    }

    .logo-bawah {
        height: 60px;
        float: left;
        margin-right: 8px;
        margin-bottom: auto;
    }

    .btn-orange {
        color: #fff;
        background-color: #fe6c17 !important;
        border-color: #fe6c17 !important;
    }

    .child-box:hover {
        border: 1px solid #c9c9c993;
    }

    /* #child-box:hover {
        border: 1px solid #fd7300;
        color: #fd7300;
    } */

    .button-action-payment li.active {
        border: 1px solid transparent;
        background: rgb(255, 255, 255);
        filter: grayscale(0%);
    }

    .xxs {
        font-size: 0.4rem;
    }

    .button-action-payment li {
        border: 1px solid rgba(202, 202, 202, 0.398);
        padding: 10px;
        border-radius: 0.3em;
        margin-bottom: 10px;
        position: relative;
        display: list-item;
        text-align: -webkit-match-parent;
        background: rgb(208, 208, 208);
        -webkit-filter: grayscale(100%);
        /* Safari 6.0 - 9.0 */
        filter: grayscale(100%);
    }

    .button-action-payment input[type="radio"]:checked+.payment-item {
        color: #fd7300;
    }


    .strip-primary {
        background-color: #fe6c17;
        position: absolute;
        width: 60px;
        height: 5px;
        border-radius: 10px;
    }

    .wave {
        min-height: 100%;
        background-attachment: scroll;
        /* background-image: url("https://bangjeff.com/assets/img/wave.svg"); */
        background-repeat: no-repeat;
        background-position: bottom left, bottom right;
    }

    .wave2 {
        min-height: 100%;
        background-attachment: fixed;
        /* background-image: url("https://bangjeff.com/assets/img/wave2.svg"); */
        background-repeat: no-repeat;
        background-position: top left, top right;
    }

    .fab-container {
        position: fixed;
        bottom: 70px;
        right: 10px;
        z-index: 999;
        cursor: pointer;
    }

    .fab-icon-holder {
        width: 45px;
        height: 45px;
        bottom: 140px;
        left: 10px;
        color: #FFF;
        background: #FFF;
        /* padding: 1px; */
        border-radius: 10px;
        text-align: center;
        font-size: 30px;
        z-index: 99999;
    }

    .fab-icon-holder:hover {
        opacity: 0.8;
    }

    .fab-icon-holder i {
        display: flex;
        align-items: center;
        justify-content: center;
        height: 100%;
        font-size: 25px;
        color: #ffffff;
    }

    .fab-options {
        list-style-type: none;
        margin: 0;
        position: absolute;
        bottom: 48px;
        left: -37px;
        opacity: 0;
        transition: all 0.3s ease;
        transform: scale(0);
        transform-origin: 85% bottom;
    }

    .fab:hover+.fab-options,
    .fab-options:hover {
        opacity: 1;
        transform: scale(1);
    }

    .fab-options li {
        display: flex;
        justify-content: flex-start;
        padding: 5px;
    }

    .fab-label {
        padding: 2px 5px;
        align-self: center;
        user-select: none;
        white-space: nowrap;
        border-radius: 3px;
        font-size: 16px;
        background: #666666;
        color: #ffffff;
        box-shadow: 0 6px 20px rgba(0, 0, 0, 0.2);
        margin-left: 10px;
    }

    .act-btn {
        display: block;
        position: fixed;
        width: 45px;
        height: 45px;
        bottom: 140px;
        left: 10px;
        color: #FFF;
        background: #5c8a8a;
        border-radius: 10px;
        text-align: center;
        font-size: 30px;
        z-index: 99999;
    }
    
    .act-btn:hover {

        background: #212529;
    }

    .act-btn-top {
        display: none;
        position: fixed;
        width: 45px;
        height: 45px;
        bottom: 140px;
        right: 10px;
        color: #FFF;
        background: #5c8a8a;
        border-radius: 10px;
        text-align: center;
        font-size: 30px;
        z-index: 99999;
    }

    .act-btn-top:hover {
        background: #212529;
    }

    .d-flex {
        display: -ms-flexbox !important;
        display: flex !important;
    }

    .d-flex2 {
        background-color: #212529;
    }

    .img-chat {
        max-width: 100%;
        height: auto;
        /* background-color: #f89728; */
        border-radius: 10px;
    }

    .btn-topup {
        color: #fff3e2 !important;
        background-color: #fe6c17 !important;
        width: 90%;
        max-width: 100px;
    }

    .btn-topup:hover {
        color: #fff3e2 !important;
        background-color: #c44d09 !important;
        border-color: #c44d09;
        width: 90%;
    }

    .rounded-img-buy {
        border-radius: 25% !important;
    }

    .size-img-buy {
        width: 90%;
        /* border-radius: 12px; */
        height: auto;

    }

    .size-img-buy-v {
        width: 90%;
        height: auto;
        text-align: center;
    }

    @font-face {
        font-family: 'bangjeff-comic';
        src: url(fonts/comic.ttf);
    }
    .bangjeff-hp1 {
        flex: 0 0 auto;
        width: 100%;
        font-size: 15px;
        /* font-family: 'bangjeff-comic'; */
        padding: 0%;
        font-style: italic;
        margin-top: 5px;
        line-height: 90%;
    }

    .bangjeff-hp2 {
        flex: 0 0 auto;
        width: 100%;
        font-size: 14px;
        /* font-family: 'bangjeff-comic'; */
        padding: 0%;
        font-style: italic;
        margin-top: 5px;
        line-height: 90%;
    }
    .bangjeff-hp3 {
        flex: 0 0 auto;
        width: 100%;
        font-size: 13px;
        /* font-family: 'bangjeff-comic'; */
        padding: 0%;
        font-style: italic;
        margin-top: 5px;
        line-height: 90%;
    }
    .col-bjconfirm {
        flex: 0 0 auto;
        width: 50%;
        font-size: 14px;
        text-align: right;
    }
    .col-bjconfirm2 {
        flex: 0 0 auto;
        width: 50%;
        font-size: 14px;
        text-align: left;
    }
    .col-bjconfirm3 {
        flex: 0 0 auto;
        width: 100%;
        font-size: 11px;
        text-align: center;
    }

    .col-bjinv {
        flex: 0 0 auto;
        width: 50%;
        font-size: 14px;
        text-align: right;
    }
    .col-bjinv2 {
        flex: 0 0 auto;
        width: 50%;
        font-size: 14px;
    }
    .col-bjinv3 {
        flex: 0 0 auto;
        width: 50%;
        font-size: 20px;
        font-weight: bold;
    }

    .nav-pills .nav-link.active,
    .nav-pills .show>.nav-link {
        background-color: #fe6c17;
        color: #fff;
    }

    .nav-link {
        color: #fe6c17;
        display: block;
        padding: 0.5rem 1rem;
        text-decoration: none;
        transition: color 0.15s ease-in-out 0s, background-color 0.15s ease-in-out 0s, border-color 0.15s ease-in-out 0s;
    }

    .nav-link:focus,
    .nav-link:hover {
        color: #c44d09;
    }
    .bangjeffbgblack {
        background-color: #1e2022;
    }

</style>

<body class="d-flex2 flex-column min-vh-100  text-white">



  <noscript><iframe src="../external.html?link=https://www.googletagmanager.com/ns.html?id=GTM-KX5ZSG5" height="0" width="0"

            style="display:none;visibility:hidden"></iframe></noscript>

<!-- NAVBAR -->
  <header class="mb-5">
<nav class="navbar navbar-expand-lg fixed-top text-white bangjeffbgblack navbar-dark shadow ">
<div class="container">
<div class="d-flex">
<span class="w-100 d-lg-none d-block">

</span>
<a class="navbar-brand d-none d-lg-inline-block" href="index.php">
<img src="assets/img/logo-ruustore.png" alt="LOGO" class="logo-atas">
</a>
<a class="navbar-brand mx-auto d-lg-none d-inline-block" href="index.php">
<img src="assets/img/logo-ruustore.png" alt="LOGO" class="logo-atas">
</a>
</div>
<button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarTogglerDemo03" aria-controls="navbarTogglerDemo03" aria-expanded="false" aria-label="Toggle navigation">
<span class="navbar-toggler-icon"></span>
</button>
<div class="collapse navbar-collapse text-right" id="navbarTogglerDemo03">
<ul class="navbar-nav ms-auto nav-stacked">
<li class="nav-item">
<a href="index.php" class="nav-link text-white ">
<i class="fa fa-home" aria-hidden="true"></i>
Home</a>
</li>
<div class="nav-item dropdown">
<a href="#" class="nav-link text-white dropdown-toggle" id="dropdownMenuButton1" role="button" data-bs-toggle="dropdown" aria-expanded="false">
<i class="fas fa-calculator"></i>
Calculator
</a>
<ul class="dropdown-menu dropdown-menu-dark shadow mb-2" aria-labelledby="dropdownMenu2">
<li class="nav-item">
<a href="calc-winrate.html" class="dropdown-item text-white"><i class="fas fa-address-card"></i> Win Rate</a>
</li>
<li class="nav-item">
<a href="calc-magicwheel.html" class="dropdown-item text-white"><i class="fas fa-address-card"></i> Magic Wheel</a>
</li>
<li class="nav-item">
<a href="calc-zodiac.html" class="dropdown-item text-white"><i class="fas fa-address-card"></i> Zodiac</a>
</li>
</ul>
</div>
</ul>
</div>
</div>
</nav>
</header>
<div class="container">
  

<!-- COROUSEL -->
<div class="wrapper pt-4 pb-4 bangjeffbgblack">
<div class="row d-lg-none d-inline-block m-0 w-100">
<div class="col-lg-12 mx-auto p-0">
<div class="carousel slide shadow" id="carousels_promo" data-bs-ride="carousel">
<div class="carousel-inner">
<div class="carousel-item active">
<a href="#">
<img src="assets/img/banner-ruustore.png" alt="" class="d-block w-100">
</a>
</div>
<div class="carousel-item ">
<a href="id/joki-bang-jeff.html">
<img src="assets/img/banner-ruustore2.jpg" alt="" class="d-block w-100">
</a>
</div>
</div>
<button class="carousel-control-prev" type="button" data-bs-target="#carousels_promo" data-bs-slide="prev">
</button>
<button class="carousel-control-next" type="button" data-bs-target="#carousels_promo" data-bs-slide="next">
</button>
</div>
</div>
</div>
<ul class="dropdown-menu dropdown-menu-dark position-absolute shadow navbar-nav-scroll" aria-labelledby="dropsearchdown" id="dropDownSearchResults">
</ul>
</form>
<!-- CONTENT -->
<div class="tab-content" id="myTabContent">
<div class="tab-pane active" id="Top_Up" role="tabpanel" aria-labelledby="Top_Up-tab">
<div class="row row-cols-3 row-cols-md-6 g-2 justify-content-left mt-2">
<div class="col mb-2">
<div class="img-scale card bg-transparent border-0 h-100 rounded p-2 text-center">
<a href="order_ml.php">
<img src="assets/img/ml.jpg" class="card-img-top rounded-img-buy size-img-buy" alt="mobile-legends-icon"></a>

<div class="card-body p-1 py-md-0 text-center mb-0 d-lg-none d-md-none">
<div class="row h-100">
<div class="bangjeff-hp3">
<small class="text-sm"><b>Mobile Legends</b></small><br>
</div>
</div>
</div>

<div class="card-body p-1 py-md-0 text-center mb-0 d-none d-md-block d-lg-none">
<div class="row h-100">
<div class="bangjeff-hp2">
<small class="text-sm"><b>Mobile Legends</b></small><br>
</div>
</div>
</div>

<div class="card-body p-1 py-md-0 text-center mb-0 d-none d-md-none d-lg-block">
<div class="row h-100">
<div class="bangjeff-hp1">
<small class="text-sm"><b>Mobile Legends</b></small><br>
</div>
</div>
</div>
</div>
</div>


<script type="25d7f2a453c98fc378ed16ea-text/javascript">
        $(document).ready(function() {
            const swiper = new Swiper('.swiper', {
                effect: "coverflow",
                grabCursor: true,
                centeredSlides: true,
                slidesPerView: "auto",
                loop:true,
                autoplay: {
                    delay: 3000,
                    disableOnInteraction: false,
                },
                coverflowEffect: {
                    rotate: 50,
                    stretch: 0,
                    // depth: 100,
                    modifier: 1,
                    slideShadows: true,
                },
                pagination: {
                    el: ".swiper-pagination",
                },
                navigation: {
                    nextEl: '.swiper-button-next',
                    prevEl: '.swiper-button-prev',
                },

            });
            $(".search_input").focusout(function() {
                setTimeout(() => {
                    $(this).parent().dropdown("hide");
                }, 300);
                let $parent = $(this).parent(".mini").parent().parent().parent().parent();
                setTimeout(() => {
                    $parent.find(".form-check").fadeIn(50);
                }, 300);
                $parent.parent().parent().find(".navbar-toggler").toggle("slide:left");
            });
            $(".search_input").focusin(function() {
                let $parent = $(this).parent(".mini").parent().parent().parent().parent();
                $parent.find(".form-check").fadeOut(50);
                $parent.parent().parent().find(".navbar-toggler").toggle("slide:left");

            });
            $(".search_input").keyup(function(e) {
                console.log(e.currentTarget)
                if (e.keyCode == 13) {
                    $(this).parent().parent().submit();
                }
                var search = $(this).val();
                $.ajax({
                    url: "https://bangjeff.com/api/search",
                    type: "POST",
                    data: {
                        q: search,
                        _token: "968Yg5tj3noBC2frQBbczPjYS5nkhIagkcRzSQiJ"
                    },
                    success: function(data) {
                        if (data.length > 0) {
                            $(e.currentTarget).parent().dropdown("show");
                            console.log($(e.currentTarget).parent());
                            $(e.currentTarget).parent().siblings("#dropDownSearchResults").html(
                                "")
                            let _results = [];
                            var sorted = {};
                            for (var i = 0, max = data.length; i < max; i++) {
                                if (sorted[data[i].category] == undefined) {
                                    sorted[data[i].category] = [];
                                }
                                sorted[data[i].category].push(data[i]);
                            }
                            for (category in sorted) {
                                _results.push(
                                    `<li><span class="dropdown-item-text"><b>${category.toUpperCase()}</b></span></li>`
                                );
                                sorted[category].forEach(element => {
                                    _results.push(`
                                        <li><a class="dropdown-item" href="id/_slug.html">
                                            <div class="row">
                                                <div class="col-3">
                                                    <img src="${element.thumbnail}" alt="" class="img-fluid">
                                                </div>
                                                <div class="col-9">
                                                    <div class="row">
                                                        <div class="col-md-12">
                                                            <b>${ element.name}</b>
                                                        </div>
                                                    </div>
                                                    <div class="row">
                                                        <div class="col-md-12">
                                                            <small>${ element.subtitle }</small>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </a></li>`
                                        .replace(':slug', element.slug))
                                })
                            }

                            $(e.currentTarget).parent().siblings("#dropDownSearchResults")
                                .append(_results
                                    .join(
                                        `<hr class="dropdown-divider">`));
                        } else {
                            $(e.currentTarget).parent().dropdown("hide");
                        }
                    }
                });
            });
        })
    </script>
</div>
<div class="modal fade" id="modalInformations" aria-hidden="true" aria-labelledby="modalInformationsLabel" tabindex="-1">
<div class="modal-dialog modal-dialog-centered modal-lg modal-dialog-scrollable">
<div class="modal-content bg-dark" style="box-shadow:0 0 3rem #000000 !important">
<div class="modal-body">
<div class="row" id="textInfo">
</div>
<div class="row">
<div class="col float-start">
<div class="form-check" style="font-size:12px">
<input class="form-check-input" type="checkbox" value="" id="dontshowinfo">
<label class="form-check-label" for="dontshowinfo">
Jangan tampilkan lagi
</label>
</div>
</div>
<div class="col text-end">
<button type="submit" name="read_popup_news_b2c" style="font-size:12px" class="btn btn-primary btn-sm">
Tutup
</button>
</div>
</div>
</div>
</div>
</div>
</div>
<style>
    .footer__clip-path[data-v-24ea0f94] {
        display: flex;
        padding: 0;
        margin-top: -39px;
        width: 100%;
        height: 40px;
        background-color: #212529;
        clip-path: polygon(0 23%,6% 72%,12% 47%,18% 70%,24% 51%,32% 80%,38% 47%,44% 80%,50% 49%,56% 70%,60% 86%,66% 42%,72% 65%,78% 38%,84% 64%,90% 17%,96% 20%,100% 1%,100% calc(100% + 1px),0 calc(100% + 1px));
        -webkit-clip-path: polygon(0 23%,6% 72%,12% 47%,18% 70%,24% 51%,32% 80%,38% 47%,44% 80%,50% 49%,56% 70%,60% 86%,66% 42%,72% 65%,78% 38%,84% 64%,90% 17%,96% 20%,100% 1%,100% calc(100% + 1px),0 calc(100% + 1px));
    }


    @media  screen and (min-width: 768px){
        .footer__clip-path[data-v-24ea0f94] {
            clip-path: polygon(0 23%,2% 55%,4% 32%,6% 50%,8% 30%,10% 75%,13% 40%,15% 62%,17% 96%,19% 50%,21% 93%,23% 46%,25% 89%,27% 64%,29% 87%,31% 76%,33% 59%,35% 96%,38% 48%,40% 82%,42% 65%,44% 48%,46% 82%,48% 66%,50% 44%,52% 56%,54% 100%,56% 65%,58% 93%,60% 49%,63% 99%,65% 44%,67% 97%,69% 87%,71% 43%,73% 68%,75% 48%,77% 67%,79% 95%,81% 64%,83% 38%,85% 85%,88% 51%,90% 81%,92% 38%,94% 80%,96% 61%,98% 40%,100% 72%,100% calc(100% + 1px),0 calc(100% + 1px));
            -webkit-clip-path: polygon(0 23%,2% 55%,4% 32%,6% 50%,8% 30%,10% 75%,13% 40%,15% 62%,17% 96%,19% 50%,21% 93%,23% 46%,25% 89%,27% 64%,29% 87%,31% 76%,33% 59%,35% 96%,38% 48%,40% 82%,42% 65%,44% 48%,46% 82%,48% 66%,50% 44%,52% 56%,54% 100%,56% 65%,58% 93%,60% 49%,63% 99%,65% 44%,67% 97%,69% 87%,71% 43%,73% 68%,75% 48%,77% 67%,79% 95%,81% 64%,83% 38%,85% 85%,88% 51%,90% 81%,92% 38%,94% 80%,96% 61%,98% 40%,100% 72%,100% calc(100% + 1px),0 calc(100% + 1px));
        }
    }
</style>
<div data-v-24ea0f94 class="footer__clip-path pt-3">
</div>
<footer class="footer mt-auto border-dark bg-dark shadow-lg">
<div class="container">
<div class="row">
<div class="col-lg-4 p-4">
<img src="assets/img/logos/ruustore.png" alt="LOGO" class="logo-bawah">
<h5 class="text-uppercase mt-2" style="margin:0">RuuStore</h5>
<i class="strip-primary"></i>
<div class="mt-2 ratakirikanan">
<p>Supplier Top Up Instant Game &amp; Voucher termurah, terpercaya, dan aman legal 100% open 24 Jam dengan payment terlengkap Indonesia</p>
</div>
</div>
<div class="container">
<div class="flex">
<div class="col-lg-2 p-4">
<h5 class="mt-2 mb-1">Payment</h5>
<i class="strip-primary"></i>
<div class="mt-3">
<img src="assets/img/logos/OVO.png" class="bangjeff-pgimg">
<img src="assets/img/logos/Dana.png" class="bangjeff-pgimg">
<img src="assets/img/logos/Shopeepay.png" class="bangjeff-pgimg">
<img src="assets/img/logos/Gopay.png" class="bangjeff-pgimg">
 <img src="assets/img/logos/qris.png" class="bangjeff-pgimg">
<img src="assets/img/logos/Linkaja.png" class="bangjeff-pgimg">
<img src="assets/img/logos/bca.png" class="bangjeff-pgimg">
<img src="assets/img/logos/mandiri.png" class="bangjeff-pgimg">
<img src="assets/img/logos/briva.png" class="bangjeff-pgimg">
<img src="assets/img/logos/bni.png" class="bangjeff-pgimg">
<img src="assets/img/logos/permatava.png" class="bangjeff-pgimg">
<img src="assets/img/logos/sinarmasva.png" class="bangjeff-pgimg">
<img src="assets/img/logos/maybankva.png" class="bangjeff-pgimg">
<img src="assets/img/logos/danamonva.png" class="bangjeff-pgimg">
<img src="assets/img/logos/cimbva.png" class="bangjeff-pgimg">
<img src="assets/img/logos/bncva.png" class="bangjeff-pgimg">
<img src="assets/img/logos/indomaret.png" class="bangjeff-pgimg">
<img src="assets/img/logos/alfamart.png" class="bangjeff-pgimg">
</div>
</div>
</div>
</div>
<div class="col-lg-2 p-4">
<h5 class="mt-2 mb-1">Chat Us</h5>
<i class="strip-primary"></i>
<div class="mt-3">
<i class="fas fa-angle-right"></i> <i class="fab fa-whatsapp"></i><a href="https://wa.me/6282170263756" target="_blank" class="text-white bjlink">
WhatsApp
</a><br>
<i class="fas fa-angle-right"></i> <i class="fab fa-instagram"></i><a href="https://instagram.com/yorustore.id" target="_blank" class="text-white bjlink">
Instagram
</a><br>
<i class="fas fa-angle-right"></i> <i class="fab fa-telegram"></i><a href="https://t.me/kii_019" target="_blank" class="text-white bjlink">
Telegram
</a><br>

</div>
</div>
</div>
</div>
<div class="container-fluid mt-2">
<div class="row bangjeffbgblack shadow" id="footer-credit">
<div class="col">
<div class="container mt-2 mb-2 text-center">
<small>
Copyright &copy; 2022 <a href="index.php" class="text-white">RuuStore</a>
All Rights Reserved
</small>
</div>
</div>
</div>
</div>
</footer>
<script data-cfasync="false" src="cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script type="25d7f2a453c98fc378ed16ea-text/javascript">
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
    </script>
<script src="assets/plugins/bootstrap-table/bootstrap-table.min.js" type="25d7f2a453c98fc378ed16ea-text/javascript"></script>
<script src="assets/admin/assets/plugins/bootstrap/js/bootstrap.min.js" type="25d7f2a453c98fc378ed16ea-text/javascript"></script>
<div class="fab-container">
<div class="fab fab-icon-holder">
<img src="assets/img/logos/chat.png" class="img-chat" alt="">
</div>
<ul class="fab-options">
 <li>
<a href="https://instagram.com/yorustore.id" class="text-decoration-none" target="_blank">
<div class="fab-icon-holder" style="background: radial-gradient(circle farthest-corner at 35% 90%, #fec564, transparent 50%), radial-gradient(circle farthest-corner at 0 140%, #fec564, transparent 50%), radial-gradient(ellipse farthest-corner at 0 -25%, #5258cf, transparent 50%), radial-gradient(ellipse farthest-corner at 20% -50%, #5258cf, transparent 50%), radial-gradient(ellipse farthest-corner at 100% 0, #893dc2, transparent 50%), radial-gradient(ellipse farthest-corner at 60% -20%, #893dc2, transparent 50%), radial-gradient(ellipse farthest-corner at 100% 100%, #d9317a, transparent), linear-gradient(#6559ca, #bc318f 30%, #e33f5f 50%, #f77638 70%, #fec66d 100%);">
<i class="fab fa-instagram"></i>
</div>
</a>
</li>
<li>
<a href="https://wa.me/6282170263756" class="text-decoration-none" target="_blank">
<div class="fab-icon-holder" style="background-color: #25D366;">
<i class="fab fa-whatsapp"></i>
</div>
</a>
</li>
<li>
<a href="https://www.facebook.com/riskicbn" class="text-decoration-none" target="_blank">
<div class="fab-icon-holder" style="background-color: #3b5998;">
<i class="fab fa-facebook"></i>
</div>
</a>
</li>
<li>
<a href="https://t.me/kii_019" class="text-decoration-none" target="_blank">
<div class="fab-icon-holder" style="background-color: #2ba0d7;">
<i class="fab fa-telegram-plane"></i>
</div>
</a>
</li>
</ul>
</div>
<script src="cdn-cgi/scripts/7d0fa10a/cloudflare-static/rocket-loader.min.js" data-cf-settings="25d7f2a453c98fc378ed16ea-|49" defer=""></script><script>(function(){var js = "window['__CF$cv$params']={r:'75e967d11c0c49a8',m:'c0hSVlolmXB0MbDzr2sMgkKJYbopQBpGuIGeXn5ZnOk-1666516917-0-AZmKvILVkDNHeeFP+DOEtJCJlZJur13ha2ijjUMycvXIgUc/KoXPgazIJvgoD6AnOtZ43AfNKkT3xu3kE8dGZIgeKdyqHmQDRSiwBnE1o2GPcODtvf5JHo6QtmPbLDUZYg==',s:[0xa5431d96ef,0x80eb72579d],u:'/cdn-cgi/challenge-platform/h/g'};var _cpo=document.createElement('script');_cpo.nonce='',_cpo.src='cdn-cgi/challenge-platform/h/g/scripts/cb/invisiblec818.js',document.getElementsByTagName('head')[0].appendChild(_cpo);";var _0xh = document.createElement('iframe');_0xh.height = 1;_0xh.width = 1;_0xh.style.position = 'absolute';_0xh.style.top = 0;_0xh.style.left = 0;_0xh.style.border = 'none';_0xh.style.visibility = 'hidden';document.body.appendChild(_0xh);function handler() {var _0xi = _0xh.contentDocument || _0xh.contentWindow.document;if (_0xi) {var _0xj = _0xi.createElement('script');_0xj.nonce = '';_0xj.innerHTML = js;_0xi.getElementsByTagName('head')[0].appendChild(_0xj);}}if (document.readyState !== 'loading') {handler();} else if (window.addEventListener) {document.addEventListener('DOMContentLoaded', handler);} else {var prev = document.onreadystatechange || function () {};document.onreadystatechange = function (e) {prev(e);if (document.readyState !== 'loading') {document.onreadystatechange = prev;handler();}};}})();</script><script defer src="../external.html?link=https://static.cloudflareinsights.com/beacon.min.js/v652eace1692a40cfa3763df669d7439c1639079717194" integrity="sha512-Gi7xpJR8tSkrpF7aordPZQlW2DLtzUlZcumS8dMQjwDHEnw9I7ZLyiOj/6tZStRBGtGgN6ceN6cMH8z7etPGlw==" data-cf-beacon='{"rayId":"75e967d11c0c49a8","token":"e63d612e8041415d81ac84b19233d5e2","version":"2022.10.3","si":100}' crossorigin="anonymous"></script>
</div>
</body>
<script type="25d7f2a453c98fc378ed16ea-text/javascript">
    mybutton = document.querySelector(".act-btn-top");
    window.onscroll = function() {
        scrollFunc()
    };

    function scrollFunc() {
        if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
            mybutton.style.display = "block";
        } else {
            mybutton.style.display = "none";
        }
    }

    function toTop() {
        document.body.scrollTop = 0;
        document.documentElement.scrollTop = 0;
    }
</script>
<script type="25d7f2a453c98fc378ed16ea-text/javascript">
    $(document).ready(function() {
        let $infoTexts = ``;
        if ($.cookie('dontshow')) {
            $infoTexts = '';
        }
        if ($infoTexts) {
            $("#modalInformations").modal('show');
            if (localStorage.getItem("lightSwitch") && localStorage.getItem("lightSwitch") !== "dark") {
                $infoTexts = $infoTexts.replace(/bg-dark/g, "bg-light");
            }
            $("#modalInformations").find("#textInfo").html($infoTexts);
        }
        $("button[name='read_popup_news_b2c']").click(function() {
            if ($("#dontshowinfo").is(":checked")) {
                var date = new Date();
                date.setTime(date.getTime() + (6 * 60 * 60 * 1000)); // jam * menit * detik * milidetik
                $.cookie('dontshow', true, {
                    expires: date
                });
            }
            $("#modalInformations").modal('hide');
        });
    })
</script>
</html>